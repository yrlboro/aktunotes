---
title: CF1 — Matematika Keuangan
description: Catatan materi dan soal ujian CF1 Matematika Keuangan PAI
---

# CF1 — Matematika Keuangan

Modul CF1 mencakup konsep nilai waktu uang, anuitas, pinjaman, obligasi, dan derivatif dasar. Bobot ujian berkisar antara **30–40 soal pilihan ganda**.

> [!tip] Referensi Utama
> Vaaler & Daniel — *Mathematical Interest Theory* · Kellison — *Theory of Interest*

---

## Materi

### Topik 1 — Nilai Waktu dari Uang

| # | Topik | Bobot |
|---|-------|-------|
| 1.1 | [[1.1 Interest Rates and Discount Rates]] | 10–20% |
| 1.2 | [[1.2 Effective, Nominal, and Force of Interest]] | 10–20% |
| 1.3 | [[1.3 Cash Flow Equations and Inflation]] | 5–10% |
| 1.4 | [[1.4 Accumulation and Present Value]] | 10–20% |
| 1.5 | [[1.5 NPV, IRR, DWRR, TWRR]] | 5–10% |

### Topik 2 — Anuitas

| # | Topik | Bobot |
|---|-------|-------|
| 2.1 | [[2.1 Annuity-Immediate and Annuity-Due]] | 15–25% |
| 2.2 | [[2.2 Perpetuity]] | 5–10% |
| 2.3 | [[2.3 Varying Annuities]] | 10–15% |
| 2.4 | [[2.4 Continuous Annuities]] | 5–10% |
| 2.5 | [[2.5 Deferred Annuities]] | 5–10% |
| 2.6 | [[2.6 Varying Interest Rates]] | 5–10% |

### Topik 3 — Yield, Duration & Imunisasi

| # | Topik | Bobot |
|---|-------|-------|
| 3.1 | [[3.1 Spot Rates and Forward Rates]] | 5–10% |
| 3.2 | [[3.2 Yield Curve]] | 5–10% |
| 3.3 | [[3.3 Duration (Macaulay and Modified)]] | 10–15% |
| 3.4 | [[3.4 Convexity]] | 5–10% |
| 3.5 | [[3.5 Immunization]] | 5–10% |

### Topik 4 — Pinjaman

| # | Topik | Bobot |
|---|-------|-------|
| 4.1 | [[4.1 Loan Terminology]] | 5–10% |
| 4.2 | [[4.2 Amortization Method]] | 10–15% |
| 4.3 | [[4.3 Sinking Fund Method]] | 5–10% |

### Topik 5 — Obligasi

| # | Topik | Bobot |
|---|-------|-------|
| 5.1 | [[5.1 Bond Pricing]] | 10–15% |
| 5.2 | [[5.2 Book Value, Premium and Discount Amortization]] | 5–10% |
| 5.3 | [[5.3 Yield Rate and Coupon Calculations]] | 5–10% |

### Topik 6 — Derivatif Dasar

| # | Topik | Bobot |
|---|-------|-------|
| 6.1 | [[6.1 Options – Call and Put]] | 5–10% |
| 6.2 | [[6.2 Forwards and Futures]] | 5–10% |
| 6.3 | [[6.3 Option Strategies]] | 5–10% |

### Topik 7 — Portofolio & CAPM

| # | Topik | Bobot |
|---|-------|-------|
| 7.1 | [[7.1 CAPM and Factor Models]] | 5–10% |
| 7.2 | [[7.2 Mean-Variance Portfolio Theory]] | 5–10% |

---

## Soal Ujian

### Past Exams

| Periode  | Soal            | Pembahasan               |
| -------- | --------------- | ------------------------ |
| Nov 2025 | [[2025-11-CF1]] | [[13. 2025-11-CF1-Pembahasan]] |
| Agu 2025 | [[2025-08-CF1]] | [[12. 2025-08-CF1-Pembahasan]] |
| Mei 2025 | [[2025-05-CF1]] | [[11. 2025-05-CF1-Pembahasan]] |
| Okt 2024 | [[2024-10-CF1]] | [[10. 2024-10-CF1-Pembahasan]] |
| Jul 2024 | [[2024-07-CF1]] | [[9. 2024-07-CF1-Pembahasan]] |
| Apr 2024 | [[2024-04-CF1]] | [[8. 2024-04-CF1-Pembahasan]] |
| Nov 2023 | [[2023-11-CF1]] | [[7. 2023-11-CF1-Pembahasan]] |
| Agu 2023 | [[2023-08-CF1]] | [[6. 2023-08-CF1-Pembahasan]] |
| Mei 2023 | [[2023-05-CF1]] | [[5. 2023-05-CF1-Pembahasan]] |
| Des 2022 | [[2022-12-CF1]] | [[4. 2022-12-CF1-Pembahasan]] |
| Agu 2022 | [[2022-08-CF1]] | [[3. 2022-08-CF1-Pembahasan]] |
| Apr 2022 | [[2022-04-CF1]] | [[2. 2022-04-CF1-Pembahasan]] |
| Nov 2021 | [[2021-11-CF1]] | [[1. 2021-11-CF1-Pembahasan]] |

### SOA-ASM Practice Exams (FM)

| # | Soal |
|---|------|
| 1 | [[ASM FM - Practice Exam 1]] |
| 2 | [[ASM FM - Practice Exam 2]] |
| 3 | [[ASM FM - Practice Exam 3]] |
| 4 | [[ASM FM - Practice Exam 4]] |
| 5 | [[ASM FM - Practice Exam 5]] |
| 6 | [[ASM FM - Practice Exam 6]] |
